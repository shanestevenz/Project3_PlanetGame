explosion(Torpedo Impact Sound) by: Mike Koenig
http://soundbible.com/1637-Torpedo-Impact.html


big-explosion(Explosion 2 Sound) by: unknown
http://soundbible.com/456-Explosion-2.html


laser(Laser Sound) by: Mike Koenig
http://soundbible.com/1087-Laser.html


theme(waiting game) by: unknown
https://www.dl-sounds.com/royalty-free/waiting-game/


purchase(Cha Ching Register Sound) by: Muska666
http://soundbible.com/1997-Cha-Ching-Register.html
