#pragma once
#include "Button.h"
class ChangeBlockButton : public df::Button
{



public:
	ChangeBlockButton();
	~ChangeBlockButton();
	virtual void callback();


};

